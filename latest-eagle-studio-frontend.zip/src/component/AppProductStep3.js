import {Form, message, Input, Button, Upload} from "antd";
import {InboxOutlined} from "@ant-design/icons";
// import Dragger from "antd/es/upload/Dragger";
import {useParams} from "react-router";
import {deleteData} from "../actions/common";
import {handleError} from "../shared/handleError";
import {useEffect, useState} from "react";
import {readLS} from "../shared/LS";

export const AppProductStep3 = props => {

    const [form] = Form.useForm();
    const [error, setError] = useState()
    const [fileList, setFileList] = useState()
    const {id} = useParams()

    const layout = {
        labelCol: { span: 4 },
        wrapperCol: { span: 16 },
    };

    const draggerProps = {
        accept: '.rar',
        name: 'file',
        action: `${process.env.REACT_APP_BASE_URL}/${id}/file`,
        progress: { strokeWidth: 6, showInfo: true },
        headers: {
            authorization: `Bearer ${readLS('findMeToken')}`
        },
        fileList: fileList,
        onSuccess: v => setFileList([{uid: v.id, ...v}]),
        onChange(info) {
            const { status } = info.file;
            if (status !== 'uploading') {
                console.log(info.file, info.fileList);
            }
            if (status === 'done') {
                message.success(`${info.file.name} file uploaded successfully.`);
            } else if (status === 'error') {
                message.error(`${info.file.name} file upload failed.`);
            }
        },

        onDrop(e) {
            console.log('Dropped files', e.dataTransfer.files);
        },
        onRemove(e) {
            if(e.response) {
                if (e?.response?.id) {
                    deleteData(`/${id}/file/${e?.response?.id}`).then(res => console.log(res.data)).catch(err => setError(handleError(err)))
                }
            } else {
                deleteData(`/${id}/file/${e?.uid}`).then(res => console.log(res.data)).catch(err => setError(handleError(err)))
            }
        }
    };

    useEffect(() => {
        form.setFieldsValue(props?.product)
        if(props.product)
            setFileList([props.product?.file])
    },[props.product])

    return(<div>
        <Form form={form} {...layout} name="control-hooks" onFinish={(v) => props.next(v)}>

            <Form.Item label="Product file:" rules={[{ required: true }]}>
                <Upload.Dragger {...draggerProps} >
                    <p className="ant-upload-drag-icon">
                        <InboxOutlined />
                    </p>
                    <p className="ant-upload-text">Click or drag file to this area to upload</p>
                    <p className="ant-upload-hint">
                        Support for a single or bulk upload. Strictly prohibit from uploading company data or other
                        band files
                    </p>
                </Upload.Dragger>
            </Form.Item>

            <Form.Item label="Price suggestion"></Form.Item>

            <Form.Item name="single_app_license" label="Single app license ($)">
                <Input style={{marginLeft: "10px"}} />
            </Form.Item>

            <Form.Item name="multi_app_license" label="Multiple app license ($)">
                <Input style={{marginLeft: "10px"}} />
            </Form.Item>

            {/* <Form.Item name="reskinned_app_license" label="Reskinned app license ($)">
                <Input style={{marginLeft: "20px"}} />
            </Form.Item> */}

            <Form.Item name="development_hours" label="Development hours">
                <Input style={{marginLeft: "10px"}} />
            </Form.Item>

            <Form.Item colon={false} label={<Button onClick={() => props.prev()} size={"large"} >Previous</Button>}>
                <Button type="primary" htmlType="submit" size={"large"} style={{float: 'right'}}>
                    Done
                </Button>
            </Form.Item>
        </Form>

    </div>)
}