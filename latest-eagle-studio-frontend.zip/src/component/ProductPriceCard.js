import {Card, Radio} from "antd";


// export const ProductPriceCard = () => {
//
//     return (<Card title="Card title" bordered={false} style={{ width: 300 }}>
//         <p>Card content</p>
//         <p>Card content</p>
//         <p>Card content</p>
//     </Card>)
// }

// const Title = props => {
//     return(<div>
//             <Radio.Group onChange={onChange} value={value}>
//                 <Radio value={1}>A</Radio>
//                 <Radio value={2}>B</Radio>
//             </Radio.Group>
//         </div>)
// }