import {Typography} from "antd";


export const NotFound = () => {
    return (<Typography.Title>Page not found</Typography.Title>)
}