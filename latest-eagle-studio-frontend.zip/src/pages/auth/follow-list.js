import {Typography} from "antd";


export const FollowList = () => {

    return (<>
            <Typography>My Followed Authors List</Typography>
            <span>You aren't following any authors currently.</span>
        </>)
}